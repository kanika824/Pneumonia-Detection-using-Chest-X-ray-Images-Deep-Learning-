import torch
import torch.nn as nn
from torchvision import models

class PneumoniaModel(nn.Module):
    def __init__(self):
        super(PneumoniaModel, self).__init__()
        # Load pre-trained DenseNet121
        # Using weights=None and loading state_dict later in a real scenario
        self.densenet = models.densenet121(weights=models.DenseNet121_Weights.DEFAULT)
        
        # Modify final classifier layer for binary classification (Normal vs Pneumonia)
        num_ftrs = self.densenet.classifier.in_features
        self.densenet.classifier = nn.Sequential(
            nn.Linear(num_ftrs, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.densenet(x)

def load_model(path=None):
    model = PneumoniaModel()
    if path:
        try:
            model.load_state_dict(torch.load(path, map_location=torch.device('cpu')))
        except Exception as e:
            print(f"Warning: Could not load weights from {path}. Using untrained classifier. Error: {e}")
    model.eval()
    return model
