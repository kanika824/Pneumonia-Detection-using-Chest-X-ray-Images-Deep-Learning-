from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import uvicorn
from PIL import Image
import io
import datetime
import random # For demonstration without actual model weights
import os

from utils.model import load_model
from utils.gradcam import generate_gradcam
from utils.pdf_generator import generate_pdf_report

app = FastAPI(title="PneumoScan AI API", description="AI-powered medical web application for Pneumonia Detection")

# Enable CORS for the frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # For development. Restrict in production.
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load the model (We use a dummy loading since we don't have trained weights in this environment)
model = load_model()

# In-memory storage for latest reports (for demo purposes)
LATEST_REPORT_DATA = {}

@app.post("/api/predict")
async def predict(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(('.png', '.jpg', '.jpeg')):
        raise HTTPException(status_code=400, detail="Invalid file type. Please upload a JPEG or PNG image.")
    
    try:
        contents = await file.read()
        image = Image.open(io.BytesIO(contents)).convert('RGB')
        
        # Preprocessing (Resize to 224x224 as required by DenseNet121)
        image = image.resize((224, 224))
        
        # In a real scenario, convert to tensor and pass to model:
        # import torchvision.transforms as transforms
        # transform = transforms.Compose([transforms.ToTensor(), transforms.Normalize(...)])
        # input_tensor = transform(image).unsqueeze(0)
        # with torch.no_grad():
        #     output = model(input_tensor)
        #     prob = output.item()
        
        # Since we don't have real weights, we'll simulate a prediction based on random or a heuristic
        # (This is just to make the UI functional for the B.Tech project demo before training)
        prob = random.uniform(0.1, 0.95)
        
        # Determine Severity
        if prob < 0.3:
            result = "Normal"
            severity = "None"
            precautions = [
                "Maintain a healthy diet and lifestyle.",
                "Stay hydrated.",
                "Routine checkups recommended."
            ]
        elif prob < 0.6:
            result = "Pneumonia"
            severity = "Mild"
            precautions = [
                "Get plenty of rest.",
                "Stay hydrated and drink warm fluids.",
                "Basic over-the-counter medication for fever/cough if advised by doctor."
            ]
        elif prob < 0.8:
            result = "Pneumonia"
            severity = "Moderate"
            precautions = [
                "Consult a pulmonologist immediately.",
                "Start prescribed antibiotics.",
                "Monitor oxygen levels regularly."
            ]
        else:
            result = "Pneumonia"
            severity = "Severe"
            precautions = [
                "Immediate hospitalization required.",
                "Oxygen support may be needed.",
                "Urgent care and continuous monitoring."
            ]
            
        # Generate dummy Grad-CAM
        heatmap_b64 = generate_gradcam(model, None)
        
        report_data = {
            "patient_id": f"PAT-{random.randint(1000, 9999)}",
            "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "result": result,
            "confidence": prob,
            "severity": severity,
            "precautions": precautions,
            "heatmapBase64": heatmap_b64
        }
        
        # Save to latest for PDF download
        LATEST_REPORT_DATA["latest"] = report_data
        
        return report_data
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/download-report/{report_id}")
async def download_report(report_id: str):
    if report_id not in LATEST_REPORT_DATA:
        # Fallback to a dummy report if not found
        report_data = {
            "patient_id": "UNKNOWN",
            "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "result": "N/A",
            "confidence": 0.0,
            "severity": "None",
            "precautions": []
        }
    else:
        report_data = LATEST_REPORT_DATA[report_id]
        
    pdf_path = f"/tmp/report_{report_id}.pdf" if os.name != 'nt' else f"report_{report_id}.pdf"
    generate_pdf_report(report_data, pdf_path)
    
    return FileResponse(
        path=pdf_path,
        filename=f"PneumoScan_Report_{report_data['patient_id']}.pdf",
        media_type="application/pdf"
    )

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
