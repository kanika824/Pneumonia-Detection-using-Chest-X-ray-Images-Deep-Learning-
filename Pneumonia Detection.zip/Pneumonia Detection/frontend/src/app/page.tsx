"use client";

import { useState } from "react";
import { UploadSection } from "@/components/UploadSection";
import { ResultSection } from "@/components/ResultSection";
import { Navbar } from "@/components/Navbar";
import { VoiceAssistant } from "@/components/VoiceAssistant";

export default function Home() {
  const [prediction, setPrediction] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);

  const handleUpload = async (file: File) => {
    setSelectedImage(file);
    setLoading(true);
    setPrediction(null);
    
    try {
      const formData = new FormData();
      formData.append("file", file);

      // In production, this points to your FastAPI backend
      const response = await fetch("http://localhost:8000/api/predict", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) throw new Error("Failed to process image");

      const data = await response.json();
      setPrediction(data);
    } catch (error) {
      console.error(error);
      alert("Error analyzing the image. Ensure the backend is running.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex-1 bg-slate-50 dark:bg-slate-950 transition-colors">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-5xl">
            AI-Powered Pneumonia Detection
          </h1>
          <p className="mt-4 max-w-2xl text-xl text-slate-500 dark:text-slate-400 mx-auto">
            Upload a chest X-ray image for instant AI analysis, severity estimation, and medical precautions.
          </p>
          <div className="mt-4 inline-block bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-200 text-sm px-4 py-2 rounded-full border border-amber-200 dark:border-amber-800">
            <span className="font-bold">Medical Disclaimer:</span> This AI system is for assistance only and not a substitute for professional medical diagnosis.
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="flex flex-col gap-6">
            <div className="glass-panel rounded-2xl p-6">
              <h2 className="text-2xl font-bold mb-4 text-slate-800 dark:text-slate-100">1. Upload Image</h2>
              <UploadSection onUpload={handleUpload} loading={loading} selectedImage={selectedImage} />
            </div>
            
            <div className="glass-panel rounded-2xl p-6">
              <h2 className="text-xl font-bold mb-4 text-slate-800 dark:text-slate-100">Voice Assistant</h2>
              <VoiceAssistant onCommand={handleUpload} />
            </div>
          </div>

          <div className="flex flex-col h-full">
            <div className="glass-panel rounded-2xl p-6 flex-1 flex flex-col">
              <h2 className="text-2xl font-bold mb-4 text-slate-800 dark:text-slate-100">2. Analysis Results</h2>
              <ResultSection prediction={prediction} loading={loading} />
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
