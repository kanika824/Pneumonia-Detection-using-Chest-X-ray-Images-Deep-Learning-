"use client";

import { motion } from "framer-motion";
import { Download, AlertTriangle, CheckCircle, Info } from "lucide-react";

interface PredictionData {
  result: "Normal" | "Pneumonia";
  confidence: number;
  severity: "Mild" | "Moderate" | "Severe" | "None";
  heatmapBase64?: string;
  precautions: string[];
}

export function ResultSection({
  prediction,
  loading,
}: {
  prediction: PredictionData | null;
  loading: boolean;
}) {
  if (loading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center py-12">
        <div className="relative">
          <div className="h-24 w-24 rounded-full border-t-4 border-primary border-r-4 border-transparent animate-spin"></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-16 w-16 bg-primary/20 rounded-full animate-pulse"></div>
        </div>
        <p className="mt-6 text-lg font-medium text-slate-600 dark:text-slate-300 animate-pulse">
          Analyzing via DenseNet121...
        </p>
      </div>
    );
  }

  if (!prediction) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center py-12 text-center text-slate-500 dark:text-slate-400">
        <Info className="h-12 w-12 mb-4 opacity-50" />
        <p>Upload an X-ray image to see the AI analysis here.</p>
      </div>
    );
  }

  const isPneumonia = prediction.result === "Pneumonia";
  const severityColors = {
    None: "text-green-600 bg-green-100 dark:bg-green-900/30 dark:text-green-400",
    Mild: "text-yellow-600 bg-yellow-100 dark:bg-yellow-900/30 dark:text-yellow-400",
    Moderate: "text-orange-600 bg-orange-100 dark:bg-orange-900/30 dark:text-orange-400",
    Severe: "text-red-600 bg-red-100 dark:bg-red-900/30 dark:text-red-400",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col h-full space-y-6"
    >
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3 mb-2">
            {isPneumonia ? (
              <AlertTriangle className="h-8 w-8 text-red-500" />
            ) : (
              <CheckCircle className="h-8 w-8 text-green-500" />
            )}
            <h3 className="text-3xl font-bold text-slate-900 dark:text-white">
              {prediction.result}
            </h3>
          </div>
          <p className="text-slate-600 dark:text-slate-400">
            Confidence Score: <span className="font-semibold text-slate-900 dark:text-slate-200">{(prediction.confidence * 100).toFixed(2)}%</span>
          </p>
        </div>
        <div className={`px-4 py-2 rounded-full font-bold text-sm ${severityColors[prediction.severity]}`}>
          Severity: {prediction.severity}
        </div>
      </div>

      {prediction.heatmapBase64 && (
        <div className="mt-6">
          <h4 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
            Grad-CAM Visualization
          </h4>
          <div className="relative rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 w-full aspect-video flex items-center justify-center">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={`data:image/jpeg;base64,${prediction.heatmapBase64}`}
              alt="Grad-CAM Heatmap"
              className="max-h-full w-auto object-contain"
            />
            <div className="absolute bottom-3 right-3 bg-black/60 text-white text-xs px-2 py-1 rounded backdrop-blur">
              AI Heatmap Overlay
            </div>
          </div>
        </div>
      )}

      <div className="mt-6 flex-1">
        <h4 className="text-sm font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-3">
          Recommended Precautions
        </h4>
        <ul className="space-y-2">
          {prediction.precautions.map((prec, i) => (
            <motion.li
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              className="flex items-start gap-2 text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-lg border border-slate-100 dark:border-slate-700/50"
            >
              <div className="h-2 w-2 rounded-full bg-primary mt-2 flex-shrink-0" />
              <span>{prec}</span>
            </motion.li>
          ))}
        </ul>
      </div>

      <div className="pt-4 border-t border-slate-200 dark:border-slate-700">
        <button
          onClick={() => window.open('http://localhost:8000/api/download-report/latest')}
          className="w-full flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 font-semibold py-3 px-6 rounded-xl transition-colors shadow-sm"
        >
          <Download className="h-5 w-5" />
          Download PDF Report
        </button>
      </div>
    </motion.div>
  );
}
