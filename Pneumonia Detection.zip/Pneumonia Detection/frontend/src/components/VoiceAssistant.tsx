"use client";

import { useState } from "react";
import { Mic, MicOff } from "lucide-react";

export function VoiceAssistant({ onCommand }: { onCommand: (file: File) => void }) {
  const [isListening, setIsListening] = useState(false);

  const toggleListening = () => {
    // Basic mock of voice API for now
    if (!isListening) {
      setIsListening(true);
      // Simulate listening and failing since we can't fully mock Web Speech API reliably here
      setTimeout(() => {
        setIsListening(false);
        alert("Voice recognition requires HTTPS and browser permissions. Try uploading manually.");
      }, 3000);
    } else {
      setIsListening(false);
    }
  };

  return (
    <div className="flex items-center gap-4">
      <button
        onClick={toggleListening}
        className={`p-4 rounded-full flex items-center justify-center transition-all ${
          isListening
            ? "bg-red-500 text-white animate-pulse shadow-lg shadow-red-500/30"
            : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
        }`}
      >
        {isListening ? <Mic className="h-6 w-6" /> : <MicOff className="h-6 w-6" />}
      </button>
      <div>
        <p className="font-medium text-slate-800 dark:text-slate-200">
          {isListening ? "Listening..." : "Voice Commands"}
        </p>
        <p className="text-sm text-slate-500 dark:text-slate-400">
          Say "Upload Image" or "Analyze"
        </p>
      </div>
    </div>
  );
}
